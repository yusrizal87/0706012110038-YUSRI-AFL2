//
//  Manage.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation
protocol Manage{
    var harga: Int { get set }
   
var namamenu: String { get set }
    var namatoko: String { get set }

}
