//
//  Menu.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation
class Menu: Manage{
    var namatoko : String
    var namamenu : String
    var harga : Int

    init(namatoko: String, namamenu: String, harga: Int ){
        self.namatoko = namatoko
        self.namamenu = namamenu
        self.harga = harga

    }
    
    
}
