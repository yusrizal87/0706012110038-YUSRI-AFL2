//
//  Shopcart.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation
protocol cartsystem{
    func additem (_ item: Store)
}

class Shopcart: cartsystem{
    var cartlist: [Store] = []
    var total: Int = 0
    
    init(){}
    init(_ cartlist: [Store],_ total: Int) {
        self.cartlist = cartlist
        self.total = total
    }
    
    
    
    func totalpayment () -> Int {
        var totalbelanja: Int = 0
        
        
        
        for item in cartlist {
            totalbelanja += item.jumlah * item.harga
        }
        
        return totalbelanja
    }
    func additem(_ item: Store) {
        cartlist.append(item)
    }
    
    func itemcheck()->Bool{
        if cartlist.isEmpty{
            return true
        }else{
            return false
        }
    }
    
    func showitem() {
        if cartlist.isEmpty{
    print("Your cart is Empty")
        print("")
        
            
        }else{
            
          
            
            var cart : [String: [String:Int]] = [:]
            for Store in cartlist {
                if cart[Store.namatoko] == nil {
                    cart[Store.namatoko] = [Store.namamenu: Store.jumlah]
                }
                else if cart[Store.namatoko]![Store.namamenu] == nil{
                    cart[Store.namatoko]![Store.namamenu] = Store.jumlah
                }
                else{
                    cart[Store.namatoko]![Store.namamenu]! += Store.jumlah
                }
            }
            
            for (nametoko,savebox) in cart{
                print()
                print("your order from \(nametoko) : ")
                for(menu , jumlah ) in savebox {
                    print("- \(menu) x \(jumlah)")
                }
            }
            
            
            print("")
            print("""
                    Press [B] to go Back
                    Press [P] to pay/checkout
                """)
            print("your choice : ")
            if let userInputBuy = readLine(), let pilihan = String?(userInputBuy){
        
                if pilihan == "B" || pilihan.lowercased() == "b"{
                    homeMenu()
                }
                else if pilihan == "P" || pilihan.lowercased() == "p"{
                   
                    repeat{
                        print("Your Total Order : \(totalpayment())")
                        print("Enter the amount of your money : ")
                            
                        if  let enter = readLine(){
                            if let enter = Int(enter){
                                if enter == 0{
                                            print("Payment can't be Zero")
                                }
                                else if enter < 0{
                                            print("Please Enter a Valid Amount!!")
                                        
                                }
                                else if enter < totalpayment(){
                                            print("Please Enter a Valid Amount!!")
                                        
                    
                                }
                                else {
                                    
                                 
                                    print("Your total order: \(totalpayment()) " )
                                    print("You pay: \(enter) Change:  \(enter - totalpayment())" )
                                    print("")
                                    print("Enjoy your meals!")
                                    print()
                                    cartlist.removeAll()
                                
                                    break
                
                                }
                                } else if enter.trimmingCharacters(in: .whitespaces).isEmpty{
                                    print("Please Enter Your Payment.")
                                        }
                                                    }
                                }while true
                }
        }
        
       
        }
    }
}
