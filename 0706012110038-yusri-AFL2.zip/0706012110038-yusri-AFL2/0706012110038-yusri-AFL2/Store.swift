//
//  store.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation
class Store: Menu {
    var jumlah : Int

    init(namatoko: String, namamenu: String, harga: Int, jumlah: Int) {
        self.jumlah = jumlah
        super.init(namatoko: namatoko, namamenu: namamenu, harga: harga)
       
    }
}

