//
//  main.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation

var TukuTuku =
toko(name: "Tuku Tuku",
     listmenu: [
    Menu(namatoko: "Tuku - Tuku", namamenu: "somey", harga: 33000),
    Menu(namatoko: "Tuku - Tuku", namamenu: "wonogiri", harga: 19000),
    Menu(namatoko: "Tuku - Tuku", namamenu: "nu grinti", harga: 8000),
    Menu(namatoko: "Tuku - Tuku", namamenu: "Air putih", harga: 5000)
        ]
)


var Xiangjia =
toko(name: "Xiang Jia",
     listmenu: [
    Menu(namatoko: "Xiang Jia", namamenu: "teh tarik", harga: 17000),
    Menu(namatoko: "Xiang Jia", namamenu: "milo tarik", harga: 51000),
    Menu(namatoko: "Xiang Jia", namamenu: "nasi hainan tarik", harga: 35000),
    Menu(namatoko: "Xiang Jia", namamenu: "kopi tarik", harga: 13000)
    ]
)


var MadamLie =
toko(name: "Madam Lie",
     listmenu: [
    Menu(namatoko: "Madam Lie", namamenu: "ayam geprek", harga: 26000),
    Menu(namatoko: "Madam Lie", namamenu: "bebek geprek", harga: 320000),
    Menu(namatoko: "Madam Lie", namamenu: "ayam goyeng", harga: 21000),
    Menu(namatoko: "Madam Lie", namamenu: "tea with ice", harga: 5000)
    ]
)


var Kopte =
toko(name: "Kopte",
     listmenu: [
    Menu(namatoko: "Kopte", namamenu: "kopi susu", harga: 15000),
    Menu(namatoko: "Kopte", namamenu: "amerikano", harga: 20000),
    Menu(namatoko: "Kopte", namamenu: "italiano", harga: 20000),
    Menu(namatoko: "Kopte", namamenu: "capucino", harga: 15000)
    ]
)


var Gisoe =
toko(name: "Gisoe",
     listmenu: [
    Menu(namatoko: "Gisoe", namamenu: "Americano", harga: 15000),
    Menu(namatoko: "Gisoe", namamenu: "picolo", harga:20000),
    Menu(namatoko: "Gisoe", namamenu: "black coffee", harga: 10000),
    Menu(namatoko: "Gisoe", namamenu: "ginger tea", harga: 15000)
    ]
)


var tuku = TukuTuku
var xiangjia = Xiangjia
var madam = MadamLie
var kopte = Kopte
var gisoe = Gisoe
var shop = Shopcart()
var loop = true


homeMenu()

func homeMenu(){
    repeat{
        loop = false
        print("""
               Welcome to UC-Walk Cafetaria
               Please choose cafetaria :
               ============================
               ----------------------------
               ============================
               [1] Tuku - tuku
               [2] xiangjia
               [3] Madam Lie
               [4] Kopte
               [5] Gisoe
               =============================
               [S]hopping Cart
               [Q]uit
               Input:
           
           """)

        

        let choose = readLine()!.lowercased()
        switch choose {
        case "1":
        tuku.order()
        print()
        case "2":
        xiangjia.order()
        print()
        case "3":
        madam.order()
        print()
        case "4":
        kopte.order()
        print()
        case "5":
        gisoe.order()
        print()
        case "s":
        shop.showitem()
        print()
        case "q":
            exit(1)
        default:
            print("Invalid option")
        }
           
        
    }while loop
}


