//
//  toko.swift
//  0706012110038-yusri-AFL2
//
//  Created by MacBook Pro on 07/04/23.
//

import Foundation
class toko {
    let name : String
    let listmenu : [Menu]
    
    init(name: String, listmenu: [Menu]) {
        self.name = name
        self.listmenu = listmenu
    }
    
    func printMenu(){
        for (i,namatoko) in self.listmenu.enumerated(){
            print("[\(i+1)] \(namatoko.namamenu) - Rp. \(namatoko.harga)")
        }
        print("[B]ack to Menu")
        
    }
    
    func order() {
        printMenu()
        print("your menu choose : ")
        let input = readLine()
        if let numMenu = Int(input ?? "0") {
                if numMenu < 1 || numMenu > listmenu.count {
                    print("Menu tidak tersedia")
                    
                    
                    
                    
                } else {
                let choosenMenu = listmenu[numMenu - 1]
            let namaToko = choosenMenu.namatoko
            let namaMenu = choosenMenu.namamenu
            let harga = choosenMenu.harga
                print("Anda memesan \(choosenMenu.namamenu) seharga \(choosenMenu.harga)")
                print("how many \(namaMenu) do you want to buy?")
                    
                    
                if let buy = readLine(), let total = Int(buy){
                    shop.additem(Store(namatoko: namaToko, namamenu: namaMenu, harga: harga, jumlah: Int(total)))
        print("Thanks you for ordering")
        print("")
                        homeMenu()
                    }
                    
                }
            
        } else if input?.lowercased() == "b" {
            print("""
                   Welcome to UC-Walk Cafetaria
                   Please choose cafetaria :
                   ============================
                   ----------------------------
                   ============================
                   [1] Tuku - tuku
                   [2] xiangjia
                   [3] Madam Lie
                   [4] Kopte
                   [5] Gisoe
                   =============================
                   [S]hopping Cart
                   [Q]uit
                   Input:
               
               """)
                print("Kembali ke menu utama")
            } else {
                print("Input tidak valid")
            }
        }
    
}
